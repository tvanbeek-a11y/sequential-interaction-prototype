# Light the torch

A single-file, greyscale, touch-first interaction study. Drag a lit match to a torch on a stone-wall sconce and hold it still to light it. See `STUDY.md` for details.

## Run

No build step and no dependencies to install. Pick one:

- Open `index.html` directly in a browser.
- Or serve the folder (recommended for testing on a phone over your local network):
  - `npm start` (runs `npx serve . -l 3000`), or
  - `python3 -m http.server 3000`

Then open `http://localhost:3000`. On a phone, use your computer's LAN IP instead of `localhost`.

## Notes

- Audio is synthesized with the Web Audio API and only starts after the first touch or click (browser autoplay policy). On iOS, the silent switch mutes it.
- One optional external resource: the "IM Fell DW Pica" font from Google Fonts, used only for the button labels. If it cannot load (offline), the page falls back to Georgia/serif.
- No images, audio files, or other assets: the wall, torch, match, flames, and sounds are all generated in code.
- Tested target: modern mobile and desktop browsers with Canvas 2D, Pointer Events, and Web Audio.
