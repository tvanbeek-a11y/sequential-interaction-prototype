# Study: Light the torch

All code is in one file, `index.html` (CSS in `<style>`, markup, then one `<script>` IIFE). Line numbers below refer to that file.

## What it does

A greyscale, touch-first interaction on a dark stone wall. The person drags a lit match to the torch in a wall sconce and holds it still against the torch head. After about 1.25 s of steady hold the torch ignites with a flare, sparks, a whoosh, and a continuous fire sound, and the room lights up. The match burns down on its own (about 38 s) while the torch is unlit, so there is mild time pressure. Everything is drawn on one `<canvas>` and synthesized in code.

## Main visual components

| Component | What it is | Where |
|---|---|---|
| Stone wall + soot | Procedural blocks, grain, soot smudge above the torch; pre-rendered once to an offscreen `scene` canvas, seeded (`mulberry32`) so it is stable across resizes | `buildScene` L177 |
| Torch and sconce | Wooden shaft, wrapped head, iron cup, back plate, bands, rivets; also pre-rendered into `scene` | `drawTorch` L238 |
| Lit match | Stick with charring gradient that creeps up as it burns, head bulb, tilt that trails motion | `drawMatch` L695 |
| Flames | Particle systems using soft radial-gradient sprites, drawn additively: match flame `MF`, torch flame `TF`, sparks `SP` | Sprites L140-L152; emission/update L616-L667; draw L763-L800 |
| Smoke | Grey particles `SM` from the heating head, the lit torch, and a burned-out match | `puffSmoke` L359; update L668-L679 |
| Lighting | A half-resolution black "darkness" canvas (82% opaque) with radial holes cut out for the match, the heating head, and the torch (two radii, flickering) | `light` L717; `render` L745-L762 |
| Pulsing indicator | White dot, faint ring, breathing halo, outward ripple on the torch head; fills as a progress arc while holding; fades out when lit or match dead | `render` L801-L836; `indA` fade L681 |
| Buttons | "Sound on/off" (top right), "Start over" / "Strike another" (bottom) | HTML L91-L96; CSS L65-L89 |

Design tokens: greyscale only (`--ink #e4e4e4`, `--dim #8c8c8c`, `--line #6a6a6a`, black background), font IM Fell DW Pica with serif fallback (CSS L11-L32).

## Interactions, feedback, states, transitions

**Input (Pointer Events on the canvas, L530-L552)**
- Press and drag anywhere: the match follows the finger with exponential smoothing. The tip is held `0.22 * S` above the finger so the hand does not cover the flame (`update` L559-L575). Releasing leaves the match hovering in place.
- Hold still near the torch: counts as holding when the flame center is within `0.15 * S` of the torch head, the pointer is down, and the smoothed speed is below `max(55, 0.18 * S)` px/s (L576-L583).
- `S` is the layout scale `min(width, height / 1.55)` set in `layout` (L155).

**Feedback**
- Visual: match flame leans toward the torch as it approaches (L611-L615); the indicator switches from rippling to a filling arc while holding; the head glows and smokes with `heat` (L668-L679, glow in `render`); on ignition the flame flares (`flare`), sparks burst (`burst` L347), and the scene brightens (`litAmt`, `litTime`).
- Audio (Web Audio, all synthesized, no files): match hiss that gets louder when moving, rising sizzle with `heat`, ignition whoosh + low thump + crackle burst, looping fire bed with random crackles, a short puff when the match dies. See `audio` L367-L494: `init` L370, `crackle` L417, `loopCrackle` L429, `ignite` L441, `puff` L470, `quietFire` L483, `levels` L487.
- Screen-reader text: a visually hidden `#hint` live region receives the state text (L496-L509); the canvas has an `aria-label`.

**States** (`setUI` L498; computed at the end of `update`, L684-L689)

| State | Condition | UI |
|---|---|---|
| `idle` | Default, match lit, torch unlit | Indicator rippling; no buttons |
| `near` | Flame within range and pointer down | Indicator ripple replaced by progress arc |
| `lit` | `torch.lit` | Indicator fades; "Start over" button appears 2.2 s after ignition |
| `out` | `match.dead` (burn reached 1) | Indicator fades; "Strike another" button appears |

**Transitions**
- `idle`/`near` to `lit`: `heat` rises at `dt / 1.25` while holding and falls at `dt / 0.7` otherwise; at `heat >= 1`, `torch.lit = true`, `audio.ignite()`, `burst()` (L584-L589). Ignition ramps with `litAmt = 1 - exp(-6 * litTime)` and `flare = exp(-1.6 * litTime)`.
- `idle` to `out`: `match.burn += dt / 38` (slows to `dt / 220` once the torch is lit); at 1 the match dies, smoke puffs, `audio.puff()` (L597-L610).
- Any state to `idle`: `reset()` (L511-L519) via the button; restores the match at `(0.5 W, 0.8 H)` and silences the fire.
- Sound toggle: `soundBtn` handler L522-L528; audio starts on first pointerdown (`audio.init()` L541). The tab being hidden suspends the AudioContext (L548-L551).
- Main loop: `frame` L839 calls `update(dt)` then `render()` each `requestAnimationFrame`, with dt clamped to 50 ms.

## State and hooks for chaining studies

All logic lives inside an IIFE and nothing is exported. For a sequential prototype:
- Completion signal: the moment `torch.lit` flips to `true` (L586-L589). Emit a custom event or callback there.
- Re-entry/reset: `reset()` (L511).
- Core state objects: `torch`, `match`, `pointer`, and the scalars `heat`, `litAmt`, `litTime` (L113-L119).
- Rendering is full-viewport (`#stage` is `position: fixed; inset: 0`), so it should be mounted as its own screen or scene, and `layout()` (L155) re-runs on window resize.
- The scene has a fixed light on the match and torch; the ambient darkness alpha is the literal `0.82` in `render` (L749).

## External dependencies and assets

- No JS libraries, build tools, or npm dependencies. No image or audio assets (everything is procedural).
- Optional network resource: Google Fonts stylesheet for "IM Fell DW Pica" (L7-L9). Falls back to Georgia/serif.
- Browser APIs used: Canvas 2D (paths, gradients, `ellipse`, shadow blur, `globalCompositeOperation` for the additive and cut-out lighting), Pointer Events with pointer capture, Web Audio API (`AudioContext`/`webkitAudioContext`), `requestAnimationFrame`, CSS `env(safe-area-inset-*)`.
- To run: open `index.html` or serve the folder (see `README.md`).
