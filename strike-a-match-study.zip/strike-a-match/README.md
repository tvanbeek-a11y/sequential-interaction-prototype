# Strike a match (interaction study)

A single-file, dependency-free HTML/Canvas/Web Audio study. Drag a match fast across a striker strip; it heats, flares and lights, then burns down.

## Run

No build step and no npm dependencies.

- **Quickest:** open `index.html` in a browser (works from `file://`).
- **Local server (recommended for testing on a phone on the same Wi-Fi):**
  - `npm start` (uses `npx serve`, port 5173), or
  - `python3 -m http.server 5173`
  - then open `http://<your-computer-ip>:5173/`.
- **Any static host** works (GitHub Pages, Netlify, etc.). Serve `index.html` as-is.

## Requirements

- A modern browser with Canvas 2D, Pointer Events and Web Audio (current Chrome, Safari, Firefox, Edge).
- Network access is optional: the only external resource is the Google Font *Bricolage Grotesque* (falls back to the system sans-serif).
- iPhone: turn the silent switch off for sound. Audio unlocks on the first touch; the very first drag may be silent on some iOS versions.

## Files

| File | Purpose |
|---|---|
| `index.html` | The whole study: CSS, markup and JavaScript |
| `STUDY.md` | Structured description of the study for reuse in a multi-study prototype |
| `package.json` | Convenience scripts only |

There are no image, audio or font files in the package. All visuals are drawn on canvas and all sound is synthesized at runtime.
