# Study: Strike a match

All code is in `index.html` (line numbers below refer to it). Single IIFE, no modules, no dependencies, no build.

## What it does

A full-screen, greyscale, touch-first interaction. The user picks up a match and drags its head across a matchbox striker strip. Friction produces a rough scrape sound, sparks, scuff marks and a growing glow on the match head. Fast enough and long enough, the match flares and lights. The flame lights the surrounding scene, leans with movement, and the stick chars until the match burns out (or is shaken out). A button then offers a new match.

## Main visual components

| Component | Description | Code |
|---|---|---|
| Scene | Vignetted dark background, matchbox face (bleeds off the bottom), grit-textured striker strip. Rendered twice at identical geometry: a dark version and a bright "lit" version | `drawScene` L121, palettes `PAL_DARK`/`PAL_LIT` L118-119, sizing in `layout` L165 |
| Flame lighting | The lit scene is revealed through a radial mask around a light source (flame, or the heating match head), so the strip grit visibly relights | `drawLight` L455, light target logic in `update` L429 |
| Match | Wood stick with grain, charred section growing from the head, bulb head that heats toward white, ember at the burn front, offset shadow | `drawMatch` L476 |
| Flame | Layered bezier teardrops (outer, white mid, dark core) plus halo, composited additively; leans against head velocity, flickers | `flamePath` L528, `drawFlame` L534 |
| Particles | Friction/ignition sparks (additive lines), smoke puffs (soft grey discs) | `spark`/`puff` L288-293, update at end of `update`, `drawParticles` L561 |
| Hint text | Single centered line at top, fades in and out | `.hint` CSS L35, `showHint` L318 |
| "Strike another match" button | Appears after the match goes out | `.btn` CSS L43, `again` L323 |
| Sound toggle | Speaker icon top right | `.snd` CSS L53, markup L69, handler L624 |
| Match-space layout | Unit scale `u` (viewport / 390x760, clamped 0.55-1.5) used for all sizes | `layout` L165 |

Visual constraint: **strictly neutral greys** (r = g = b). Keep this if the study is merged into a sequence.

## User actions

| Action | Behavior | Code |
|---|---|---|
| Press anywhere on canvas | Picks up the match. If the press is on the stick it keeps its grip point (no jump); otherwise it grabs the stick by its middle | `pointerdown` L595, `grab` L588 |
| Drag | Head follows the grip point with ~28 ms smoothing; stick pivots about the grip and leans with horizontal velocity | `pointermove` L605, head/angle in `update` L343-349 |
| Release | Match stays where it is (not dropped). Unlit match relaxes back to resting lean | `release` L609-611 |
| Drag head across strip, fast | Builds heat; ignites when heat reaches a per-match random threshold (0.8-1.05) | `update` L364-392 |
| Whip/shake a lit match | Sustained head speed above 2300 u-px/s for 0.22 s (after 1.3 s of burning) extinguishes it | `update` L394-405 |
| Enter / Space on focused canvas | Scripted two-leg strike for keyboard users | `keydown` L614 |
| "Strike another match" | Resets to a new match at rest | L623, `newMatch` L111 |
| Sound button | Mutes/unmutes master gain | L624 |

Speeds are measured in `u`-normalized px/s (`vN`), so behavior is consistent across screen sizes.

## States and transitions

Match state machine (`m.state`):

```
ready --(heat >= need while dragging fast on strip)--> lit      ignite() L298
lit   --(burned to 90% of stick, or shaken out)------> out      extinguish() L308
out   --("Strike another match" tapped)---------------> ready   newMatch() L111
```

- **ready:** heat rises at `(vN - 250)/200` per second while in contact and faster than 250; falls at 0.6/s when in contact but slow; falls at 1.4/s when off the strip. Head glows with heat. Slow dragging for 0.5 s shows "Too slow. Drag faster." for 1.6 s. Code: `update` L384-392.
- **lit:** first 0.4 s is a flare (flame size ~2.2x decaying), plus screen flash, spark burst, haptic buzz (`navigator.vibrate(16)`, where supported). The stick rotates smoothly to `A_HELD` (L98) so the flame rises clear of it. Char grows over ~16 s; flame fades during the last 12% of burn. "Shake it to blow it out" shows between 1.8 s and 7 s. Code: `ignite` L298, `update` L394-410.
- **out:** ember fades over 1.6 s, smoke emits for 2.5 s, button appears after 0.8 s. Code: `update` L411-418.
- **Light source:** follows the flame while lit, the match head while heating, and fades otherwise (smoothed, ~50 ms). `update` L429-440.

## Feedback

| Feedback | Trigger | Code |
|---|---|---|
| Scrape sound (rough, granular noise; volume, pitch and brightness scale with speed; random flutter for stick-slip) | Head on strip and moving | `makeScrapeBuffer` L186, `updateScrape` L275 |
| Contact tick | Head first touches strip while moving | `sndTick` L251 |
| Ignition: hiss sweep, low thump, crackle | `ignite()` | `sndIgnite` L252 |
| Flame loop and random crackles | While lit | `startFlameSound` L262, `update` L394-410 |
| Extinguish hiss | `extinguish()` | L308 |
| Head glow, sparks, head jitter, scuff marks drawn permanently onto both scene canvases | Friction | `update` L364-383, `drawMatch` jitter L476 |
| Hint text | State / slow-stroke | `update` L419-428 |

## Audio design notes

- Web Audio only, no audio files. Created lazily on first pointer/key press (`initAudio` L205) and resumed on `pointerup`/`touchend`/`click`/`keydown` (L231) for iOS.
- Graph: looping scrape buffer -> two filtered layers (bandpass "grit", lowpass "thump") -> master gain -> compressor -> destination. One-shot sounds use filtered noise bursts (`burst` L237).
- Suspends on `visibilitychange` (L232).

## Accessibility and motion

Canvas is focusable with `role="img"` and an aria-label; hint is `aria-live="polite"`; buttons are 44 px; visible focus styles (CSS L51). `prefers-reduced-motion` disables the white flash and head jitter and reduces flame flicker/sway (`reduce` flag).

## Tuning constants worth knowing

`u` scale (L165), stick length `Ls = 215u` (L165), ignition speed floor 250 and gain divisor 200 (L385), `need` range (L106), burn time 16 s (L395), blow-out speed 2300 / 0.22 s (L401), `A_HELD` 2.3 (L98), light radius 300u (L432).

## Dependencies and assets

- **None at runtime** apart from one optional web font: Google Fonts *Bricolage Grotesque* (weight 500) via `<link>` in `<head>` (L8-10). Fallback stack is `system-ui` sans-serif.
- No images, audio files, or libraries. No localStorage/network calls.
- Browser APIs used: Canvas 2D, Pointer Events (+ pointer capture), Web Audio, `matchMedia`, `navigator.vibrate` (optional).

## Notes for combining with other studies

- The study owns the whole viewport (`canvas` is `position:absolute; inset:0`), sets `touch-action:none`, `overflow:hidden` and a fixed dark `--bg` on `:root`/`body`, and applies safe-area padding on `:root`. A host shell should mount it in its own container or iframe, or lift those rules.
- Everything lives in one IIFE with no public API. To drive it from a sequence, the natural seams are: `ignite()` (success event), `extinguish()` (end event), `newMatch()` (reset), and `m.state` (current state). Exposing these (e.g. returning `{ onIgnite, onOut, reset }` from the IIFE) is the minimal refactor.
- Audio context, rAF loop, `resize` and `visibilitychange` listeners are global; a host should start/stop them when switching studies (there is currently no teardown).
- IDs used in the DOM: `c`, `hint`, `again`, `snd`. Namespace them if other studies share a page.
- Palette is greyscale only; typography is a single face at 16-17 px.
