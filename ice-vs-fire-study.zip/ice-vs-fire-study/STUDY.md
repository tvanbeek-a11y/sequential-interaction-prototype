# Study: Ice vs. Fire

Source file: `index.html` (line numbers below refer to it). Single self-contained file, vanilla JS + Canvas 2D, no dependencies or assets.

## 1. What the study does

A one-screen, greyscale, mobile-first game-like interaction. The person pulls back anywhere on screen, slingshot style, to aim and power a block of ice. On release the block slides across a slippery floor, bounces off the arena walls, and (if aimed well) slams into a burning pile of wood. The ice melts and the fire shrinks; once the fire is out, an end card offers another round.

Core idea worth reusing: **drag-to-aim with a physics-accurate predicted path** (the target line), then a **release that commits the action**.

## 2. Main visual and interactive components

| Component | Description |
|---|---|
| Arena | Dark speckled floor, rounded outline, outside shaded. Block bounces off the outline. |
| Ice block | Rounded, glassy light-grey square with shine bands, cracks, bubbles, soft shadow. Shrinks as it melts. Slight tilt/spin on wall hits. |
| Wood pile and fire | Four crossed logs, additive-blend flame particles, sparks, a flickering glow lighting the floor. Logs darken as health drops. |
| Aim UI | Rubber band from touch-down point to finger, anchor ring, handle ring, dotted target line, end-of-path marker, power ring around the block. |
| HUD | Top-left push counter, top-centre fire-health bar, top-right restart button. |
| Hint | Bottom text "Drag back to aim, let go to push", fades after the first push. |
| End card | Full-screen overlay "Fire's out." + push count + "Go again" button. |
| Particles | Flames, sparks (additive), steam and smoke (normal blend), melt puddles, slide trail. |

## 3. User actions, feedback, states, transitions

**Actions**
- Press and drag anywhere (only when the block is at rest and the round is in play): starts aiming.
- Release: launches the block opposite to the drag direction. Speed = 150 to 1050 px/s scaled by pull distance (capped at 150 px).
- Release with a pull under 14 px, or pointer cancel: aim cancelled, nothing happens.
- Restart button (top right) or "Go again": new round.
- Touches while the block is moving, gone, or the round is won are ignored.

**Feedback**
- Dotted path updates live while dragging, including wall bounces; the dots fade with distance.
- If the predicted path reaches the fire: a pulsing dashed ring appears around the fire. Otherwise: a dashed ghost square shows where the block will stop.
- Power ring around the block fills clockwise with pull strength.
- On launch: small puff behind the block, push counter increments, hint fades out, short vibration (`navigator.vibrate`, where supported).
- On first contact with fire: block loses 55% of its speed, steam burst, short vibration. While in contact: heavy drag, block shrinks, fire health falls, steam and puddles spawn.
- Fire visibly shrinks, dims and smokes as health drops; the HUD bar tracks health. Fire slowly regrows (about 4% per second) when not touched.
- Wall hits add a little random spin to the block.

**States**
- `state = 'play'` – normal play. Sub-states of the block: at rest (can aim), sliding, in fire (melting), gone (melted, waiting to respawn).
- `state = 'won'` – fire health reached 0. Smoke and steam burst, flames stop.

**Transitions**
- play to block melted (mass at or below 0.08): steam burst, block hidden, new block pops in at bottom centre after 0.9 s (scale-in with overshoot). Fire keeps its remaining health.
- play to won: after 1.1 s the end card fades in (0.6 s opacity transition).
- won or play to new round (restart / "Go again"): fire placed at a new random position, health 1, pushes reset to 0, particles cleared, fresh block, end card hidden.

## 4. Where things are implemented (`index.html`)

**Markup**
- Canvas: line 106
- HUD (pushes, fire bar, restart): lines 108–114
- Hint: line 116
- End card: lines 118–125

**CSS**
- Theme tokens, safe-area padding: line 9
- HUD, bar, icon button, hint, end card, pill button: lines 58–105

**JS (inside one IIFE starting line 127)**
- Tuning constants (friction, speeds, pull limits, physics step, fire radius): line 134
- State objects (`fire`, `ice`, `aim`, particle list): line 144
- Helpers and pre-rendered soft sprites: lines 156–181
- Floor texture: `buildFloor`, line 189
- Layout, spawning, resize, new round: `placeFire`, `spawnIce`, `resize`, `newRound`, lines 213–247
- Physics: `stepBody` (friction, walls), `predict` (aim-line simulation using the same physics): lines 249–277
- Per-step simulation (melt, fire damage, win/respawn logic): `simulate`, line 287
- Particles: `burst`, `emit`, `updateParticles`: lines 279, 350, 378
- Drawing: wood and logs (394–435), ice block (436), target-line dots (`dotsAlong`, 481), aim UI (`drawAim`, 496), particles (`drawParticles`, 559), full frame (`render`, 581)
- HUD updates: `hud`, line 639
- Input (pointer events, launch): lines 645–678
- Main loop (fixed 1/120 s physics step, end-card trigger): `frame`, line 682

## 5. External dependencies and assets

- None. No libraries, fonts, images, or network requests. All art is drawn procedurally on a `<canvas>`; fonts use the system stack.
- Requires a browser with Canvas 2D, Pointer Events, `ResizeObserver`, and `CanvasRenderingContext2D.ellipse`/`arcTo` (all current mobile and desktop browsers).
- Optional: `navigator.vibrate` for haptics (silently skipped if unsupported).
- Page declares `viewport-fit=cover` and uses `env(safe-area-inset-*)` for notched phones.

## 6. Notes for chaining into a sequential prototype

- The code is wrapped in an IIFE and exposes nothing globally. To connect studies, expose a small API or dispatch events, for example a `fire-out` event when `state` becomes `'won'` (inside `simulate`, around the `fire.health <= 0` branch) with `{ pushes }` in the detail, and a `reset()` that calls `newRound`.
- The "Go again" button (`#again`) is the natural place to replace with "Next" in a sequence.
- Visual language: greyscale only, dark scene lit by the fire, white dotted guides, round 44 px touch targets. Colors are tokens on `:root` (line 9) so a shared stylesheet can override them.
- Canvas sizes itself to `#stage`, so it can be embedded in any full-screen container.
