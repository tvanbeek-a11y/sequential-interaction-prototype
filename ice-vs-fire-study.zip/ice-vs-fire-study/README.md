# Ice vs. Fire (study)

A greyscale, mobile-first slingshot interaction: drag back to aim, release to slide a block of ice into a burning pile of wood.

## Run it

No build step, no dependencies, no network access needed.

- Open `index.html` directly in a browser, or
- Serve the folder: `python3 -m http.server 8000` then visit `http://localhost:8000`
- For a phone on the same network, visit `http://<your-computer-ip>:8000`

Works with touch, mouse, and pen (Pointer Events). Best viewed full-screen on a phone-sized viewport.

## Files

- `index.html` – the whole study (HTML, CSS, JS inline; about 28 KB)
- `STUDY.md` – what it does, how it is built, and where each behaviour lives
