# Study: Torch throw (greyscale, mobile)

A single-screen, touch-first interaction: hold a lit torch, drag to aim, slide up to throw it onto a pile of wood, and watch the pile catch fire. Everything is drawn in greyscale on one `<canvas>`; all sound is synthesised in the browser.

Line numbers below refer to `index.html` as shipped. Function names are the stable handle if lines drift.

## What the study does

The player sees a night scene (moon, pines, mist, ground) with a lit torch at the lower left and a log pile at the right. They throw the torch onto the pile. A hit ignites a fire with a flash, sparks, flames, smoke and a roaring/crackling sound. A miss bounces and fizzles, then the torch relights for another try. After a successful fire, a button resets the scene with the pile in a new position.

## Main visual and interactive components

| Component | What it is | Code |
|---|---|---|
| Scene backdrop | Pre-rendered offscreen canvas: sky gradient, stars, moon, hills, two pine rows, mist, ground, grass and stones | `buildBg()` L130 |
| Log pile | 11 logs (side-on and end-on) built from a seeded RNG, drawn with bark lines, shadow, and ember glow when burning | `buildPile()` L195, `drawPile()` L536 |
| Torch | Rotated stick with a wrapped head, rim glow and head glow sprite | `drawTorchBody()` L608, `drawTorchGlow()` L626 |
| Aim indicator | Short line from the torch tip. Direction = launch angle, length = power. Dashed and dim until the slide counts as a throw, then solid with an arrowhead | `drawAim()` L635 |
| Idle cue | Pulsing ring around the resting torch | `drawIdleCue()` L657 |
| Particles | Flames and embers (additive), smoke (normal blend), from the torch trail and the pile | `spawn()` L295, `updateParticles()` L299, `emitTorch()` L316, `emitFire()` L329, `burst()` L350, `drawSmoke()` L582, `drawFlames()` L591 |
| Lighting | Additive radial glows from the fire (plus ground pool) and the torch | `drawLights()` L513 |
| Finishing | Vignette, film grain, fade-to-black transition | `render()` L664 |
| HUD | Hint text (`#hint`), sound toggle (`#sound`), reset button (`#again`) | HTML L50-53, CSS L29-46, `setHint()` L360 |
| Audio | Web Audio synthesis: ignition whoosh, thump, crackles, pops, looping fire roar, torch hiss, throw whoosh, fizzle | `initAudio()` L209, `noiseBurst()` L233, `sfxIgnite()` L256, `audioUpdate()` L269 |

## User actions

1. **Press on the torch** (within about 90 px of it) to pick it up.
2. **Drag left/right** to aim. Dragging right lowers the angle, left raises it. Angle = 50° minus 0.22° per px of horizontal drag, clamped to 14°-80°.
3. **Drag up** for power. Power = upward drag / 200 px, clamped 0-1. Launch speed = `GW * (1 + 1.2 * power)`, with gravity `GW * 3.2`, where `GW` is the play width (max 520 px).
4. **Release** to throw if power >= `READY` (0.15, about 30 px of upward slide). Otherwise the torch returns and nothing is thrown.
5. **Tap "Light another pile"** (appears after a hit) to reset the scene.
6. **Tap the sound toggle** to mute or unmute.

Input handlers: `pointerdown` L410, `pointermove` L420, `endDrag` L425, `againBtn` click L434, `soundBtn` click L285. Page scrolling is blocked with `touch-action: none` and a `touchmove` preventDefault (L433).

## States, feedback and transitions

The game is a small state machine in the variable `mode` (L83), advanced by `update(dt)` (L437).

| State | Entered when | Feedback | Leaves when |
|---|---|---|---|
| `idle` | Start, cancelled drag, torch relit, scene reset | Torch bobs; pulsing ring; hint "Hold the torch, drag to aim, then slide up to throw" | Pointer down on the torch |
| `aim` | Pointer down on the torch | Torch follows the finger and tilts; aim line; soft flare sound; hint "Slide up to throw", then "Let go to throw" once power >= 0.15 | Release (throw or cancel) |
| `fly` | Release with enough power (`launch()` L372) | Spinning torch with flame trail and sparks; throw whoosh; hint cleared | Hits the pile, hits the ground, or leaves the screen sides |
| `lit` | Torch head, centre or tail touches the pile profile (`checkHit()` L368, `ignite()` L378) | White flash, burst of flames and embers, ignition sound, haptic vibration where supported, fire ramps up, roar and crackle, hint "The pile is burning" | Reset button (after 2.6 s the button fades in) |
| `miss` | Ground contact after up to two bounces, or exit off screen (`groundHit()` L390, `missOffscreen()` L399) | Bounce, fizzle sound, flame fades, hint "Missed. Try again" | After 2.1 s: `resetTorch()` L400 returns to `idle` with a relight flare |

Reset transition (`startReset()` L404, handled in `update()`): a 1.3 s fade through black. At the midpoint the pile moves to a new random position (`pile.frac` between 0.66 and 0.86 of the play width, at least 0.08 away from the last), fire and particles are cleared, and the state returns to `idle`.

Fire intensity is `burn` (0-1) easing toward `burnTarget`; `flash` is a short decaying spike at ignition. Audio levels follow `burn` in `audioUpdate()`.

## Where to tune

- Throw feel: the aim and power mapping in `update()` (the `mode === 'aim'` block), launch speed in `launch()`, gravity in the `fly` block, `READY` constant (L81).
- Target size: `pile.w` / `pile.h` in `layout()` L114 and the hit profile in `onPile()` L362.
- Fire look: rates and sizes in `emitFire()` L329, glow in `drawLights()` L513.
- Layout: `horizonY`, `groundY`, `landY`, `start` in `layout()` L114.

## Notes for connecting this study to other interactions

- There is no module system. All code is one IIFE inside `<script>`, and nothing is exposed on `window`.
- The natural hand-off points are the state transitions: success is the move into `lit` in `ignite()`, and failure is the move into `miss`. A sequential prototype could fire a callback or custom event from those functions, and start or reset the study through `resetTorch()` / the reset transition in `update()`.
- Audio is created on the first pointer press (`initAudio()`), which browsers require. A host app that already owns an `AudioContext` should pass it in rather than creating a second one.
- The page theme is fixed on purpose (a night scene), so it does not switch with light/dark mode.

## Dependencies and assets

- **None.** One file, no libraries, no fonts to download, no images or audio files. The font stack is system serif (Iowan Old Style, Palatino, Georgia).
- Browser features used: Canvas 2D, Pointer Events, Web Audio API, `ResizeObserver`, `ctx.roundRect` (falls back to plain rectangles), `navigator.vibrate` (optional).

## Run it

- Open `index.html` directly in a browser, or serve the folder: `python3 -m http.server 8000` and visit `http://localhost:8000`.
- On a phone, serve it on your local network, or open the file from the device. On desktop, a mouse works like a finger, and device emulation in browser dev tools gives the phone layout.
- No install or build step.
